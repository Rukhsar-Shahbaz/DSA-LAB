#include <iostream>
using namespace std;
class Node{
	public:
		int data;
		Node* left;
		Node* right;
		Node(int val){
			data = val;
			left = NULL;
			right = NULL;
		}
		
	Node* insert(Node* root, int val){
		if(root == NULL){
			return new Node(val);
		}
		if(val< root->data){
			root->left = insert(root->left, val);
		}
		else if(val > root->data){
			root->right = insert(root->right, val);
		}
		return root;
	}
	void inorder(Node* root){
		if(root != NULL){
			inorder(root->left);
			cout << root->data << " ";
			inorder(root->right);
		}
	}
	void preorder(Node* root){
		if(root != NULL){
			cout << root->data << " ";
			preorder(root->left);
			preorder(root->right);
		}
	}
	void postorder(Node* root){
		if(root != NULL){
			postorder(root->left);
			postorder(root->right);
			cout << root->data << " ";
		}
	}
};
int main(){
	Node* root = NULL;
	Node node(0);
	root = node.insert(root, 13);
	root = node.insert(root, 11);
	root = node.insert(root, 9);
	root = node.insert(root, 10);
	root = node.insert(root, 14);
	root = node.insert(root, 18);
	root = node.insert(root, 6);
	 
	cout << "Inorder: " ;
	node.inorder(root);
	cout << endl;
	
	cout << "Pre-order: ";
	node.preorder(root);
	cout << endl;
	
	cout << "Post-order: ";
	node.postorder(root);
	cout << endl;
	 
}
