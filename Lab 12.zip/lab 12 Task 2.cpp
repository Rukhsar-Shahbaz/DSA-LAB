#include <iostream>
using namespace std;

class Node {
public:
    int key;
    int height;
    Node* left;
    Node* right;

    Node(int k) {
        key = k;
        height = 1;
        left = NULL;
        right = NULL;
    }
};

class AVL {
public:
    int getHeight(Node* n) {
        if (n == NULL)
            return 0;
        return n->height;
    }

    int getBalance(Node* n) {
        if (n == NULL)
            return 0;
        return getHeight(n->left) - getHeight(n->right);
    }

    int max(int a, int b) {
        return (a > b) ? a : b;
    }

    Node* rotateRight(Node* y) {
        Node* x = y->left;
        Node* t2 = x->right;

        x->right = y;
        y->left = t2;

        y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
        x->height = max(getHeight(x->left), getHeight(x->right)) + 1;

        return x;
    }

    Node* rotateLeft(Node* x) {
        Node* y = x->right;
        Node* t2 = y->left;

        y->left = x;
        x->right = t2;

        x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
        y->height = max(getHeight(y->left), getHeight(y->right)) + 1;

        return y;
    }

    Node* insert(Node* root, int key) {
        if (root == NULL)
            return new Node(key);

        if (key < root->key)
            root->left = insert(root->left, key);
        else if (key > root->key)
            root->right = insert(root->right, key);
        else
            return root;

        root->height = 1 + max(getHeight(root->left), getHeight(root->right));
        int balance = getBalance(root);

        if (balance > 1 && key < root->left->key)
            return rotateRight(root);

        if (balance < -1 && key > root->right->key)
            return rotateLeft(root);

        if (balance > 1 && key > root->left->key) {
            root->left = rotateLeft(root->left);
            return rotateRight(root);
        }

        if (balance < -1 && key < root->right->key) {
            root->right = rotateRight(root->right);
            return rotateLeft(root);
        }

        return root;
    }

    void inorder(Node* root) {
        if (root != NULL) {
            inorder(root->left);
            cout << root->key << " ";
            inorder(root->right);
        }
    }

    void preorder(Node* root) {
        if (root != NULL) {
            cout << root->key << " ";
            preorder(root->left);
            preorder(root->right);
        }
    }

    void postorder(Node* root) {
        if (root != NULL) {
            postorder(root->left);
            postorder(root->right);
            cout << root->key << " ";
        }
    }
};

int main() {
    AVL tree;
    Node* root = NULL;

    root = tree.insert(root, 30);
    root = tree.insert(root, 20);
    root = tree.insert(root, 40);
    root = tree.insert(root, 10);
    root = tree.insert(root, 25);

    cout << "Inorder: ";
    tree.inorder(root);
    cout << endl;

    cout << "Preorder: ";
    tree.preorder(root);
    cout << endl;

    cout << "Postorder: ";
    tree.postorder(root);
    cout << endl;

    return 0;
}

