#include <iostream>
using namespace std;
class Node {
public:
    int data;
    Node* next;
    Node(int val) { 
        data = val; 
        next = NULL;
      }
};
class Queue {
private:
    Node* front;
    Node* back;
public:
    Queue() { 
       front = back = NULL;
 }
 void enqueue(int val) {
 Node*newNode=new Node(val);
        if (back==NULL){
 front = back = newNode;
      } else {
      back = back->next = newNode;
}
    }

    void dequeue() {
        if (front==NULL) { 
  cout<<"Queue is empty!"<<endl;
       }
        Node* temp = front;
        front = front->next;
        if (front==NULL) {
          back = NULL;
       }
        delete temp;
    }
 void display() {
      if (front== NULL) { 
cout <<"Queue is empty!"<< endl; 
         }
        Node* temp = front;
        while (temp != NULL) {  
           cout << temp->data << "->";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
};

int main() {
    Queue q;
    q.enqueue(5);
    q.enqueue(9);
    q.enqueue(3);
    cout << "Queue elements: ";
    q.display();
    q.dequeue();
    cout << "After dequeue: ";
    q.display();
    return 0;
}
