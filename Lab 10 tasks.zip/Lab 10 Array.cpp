#include <iostream>
using namespace std;
#define n 10
class stack{
	int* arr;
	int top;
		public:
			stack(){
				arr = new int[n];
				top = -1;
			}
		void push(int x){
			if(top == n-1){
				cout << "stack overflow" << endl;
				return;
			}
			top++;
			arr[top] = x;
		}
		void pop(){
			if(top ==-1){
				cout << "No element to pop" << endl;
				return;
			}
			top--;
		}
		void display() {
            if (top == -1) {
            cout << "Stack is empty" << endl;
            return;
        }
        cout << "Stack elements: ";
        for (int i = top; i >= 0; i--) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
		
};

int main(){
	stack st;
	st.push(4);
	st.push(3);
	st.push(2);
	cout << "Before pop" << endl;
	st.display();
	st.pop();
	st.pop();
	cout << "After pop" << endl;
	st.display();
}
