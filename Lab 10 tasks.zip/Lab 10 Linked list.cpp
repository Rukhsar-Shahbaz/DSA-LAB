#include <iostream>
using namespace std;
class Node{
	public:
		int data;
		Node* next;
};
class stack{
	Node* top;
	public:
		stack(){
			top = NULL;
		}
		void push(int x){
			Node *newNode = new Node();
			newNode->data = x;
			newNode->next = top;
			top = newNode;
		}
		void pop(){
			if(top == NULL){
				cout << "No element to pop" << endl;
				return;
			}
			Node* temp = top;
			top = top->next;
			delete temp;
		}
		void display(){
			if(top == NULL){
				cout<< "Stack is empty" << endl;
			}
			cout << "Stack emlements" << endl;
			Node* temp = top;
			while(temp != NULL){
				cout << temp->data << " ";
				temp = temp->next;
			}
			cout << endl;
		}
};
int main(){
	stack st;
	st.push(6);
	st.push(7);
	st.push(9);
	st.push(3);
	st.display();
	st.pop();
	st.pop();
	st.display();
}
