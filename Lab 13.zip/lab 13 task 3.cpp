#include <iostream>
#include <queue>
using namespace std;

class Node {
public:
    int data;
    Node* child;

    Node(int d) {
        data = d;
        child = NULL;
    }
};

class Tree {
public:
    Node* insert(Node* root, int value) {
        if (root == NULL)
            return new Node(value);
        else
            root->child = insert(root->child, value);
        return root;
    }

    void preorder(Node* root) {
        if (root != NULL) {
            cout << root->data << " ";
            preorder(root->child);
        }
    }

    void inorder(Node* root) {
        if (root != NULL) {
            inorder(root->child);
            cout << root->data << " ";
        }
    }

    void postorder(Node* root) {
        if (root != NULL) {
            postorder(root->child);
            cout << root->data << " ";
        }
    }

    void bfs(Node* root) {
        if (root == NULL)
            return;

        queue<Node*> q;
        q.push(root);

        while (!q.empty()) {
            Node* current = q.front();
            q.pop();

            cout << current->data << " ";

            if (current->child != NULL)
                q.push(current->child);
        }
    }
};

int main() {
    Tree t;
    Node* root = NULL;

    root = t.insert(root, 5);
    t.insert(root, 10);
    t.insert(root, 15);
    t.insert(root, 20);

    cout << "Preorder Traversal: ";
    t.preorder(root);
    cout << endl;

    cout << "Inorder Traversal: ";
    t.inorder(root);
    cout << endl;

    cout << "Postorder Traversal: ";
    t.postorder(root);
    cout << endl;

    cout << "BFS Traversal: ";
    t.bfs(root);
    cout << endl;

    return 0;
}

