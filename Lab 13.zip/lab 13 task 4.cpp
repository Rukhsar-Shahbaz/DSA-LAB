#include <iostream>
#include <queue>
using namespace std;

class Node {
public:
    int data;
    Node* child;

    Node(int d) {
        data = d;
        child = NULL;
    }
};

class Graph {
public:
    Node* nodes[5];
    bool visited[5];

    Graph() {
        for (int i = 0; i < 5; i++) {
            nodes[i] = NULL;
            visited[i] = false;
        }
    }

    void addEdge(int u, int v) {
        Node* newNode = new Node(v);
        newNode->child = nodes[u];
        nodes[u] = newNode;

        newNode = new Node(u);
        newNode->child = nodes[v];
        nodes[v] = newNode;
    }

    void preorder(int start) {
        visited[start] = true;
        cout << start << " ";

        Node* temp = nodes[start];
        while (temp != NULL) {
            if (!visited[temp->data]) {
                preorder(temp->data);
            }
            temp = temp->child;
        }
    }

    void inorder(int start) {
        visited[start] = true;

        Node* temp = nodes[start];
        bool firstChildVisited = false;

        while (temp != NULL) {
            if (!visited[temp->data]) {
                inorder(temp->data);
                firstChildVisited = true;
                break;
            }
            temp = temp->child;
        }

        cout << start << " ";

        temp = nodes[start];
        while (temp != NULL) {
            if (!visited[temp->data]) {
                inorder(temp->data);
            }
            temp = temp->child;
        }
    }

    void postorder(int start) {
        visited[start] = true;

        Node* temp = nodes[start];
        while (temp != NULL) {
            if (!visited[temp->data]) {
                postorder(temp->data);
            }
            temp = temp->child;
        }
        cout << start << " ";
    }

    void bfs(int start) {
        queue<int> q;
        visited[start] = true;
        q.push(start);

        while (!q.empty()) {
            int node = q.front();
            q.pop();
            cout << node << " ";

            Node* temp = nodes[node];
            while (temp != NULL) {
                if (!visited[temp->data]) {
                    visited[temp->data] = true;
                    q.push(temp->data);
                }
                temp = temp->child;
            }
        }
    }
};

int main() {
    Graph g;
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 3);
    g.addEdge(2, 4);

    cout << "Preorder Traversal: ";
    g.preorder(0);
    cout << endl;

    fill(g.visited, g.visited + 5, false);
    cout << "Inorder Traversal: ";
    g.inorder(0);
    cout << endl;

    fill(g.visited, g.visited + 5, false);
    cout << "Postorder Traversal: ";
    g.postorder(0);
    cout << endl;

    fill(g.visited, g.visited + 5, false);
    cout << "BFS Traversal: ";
    g.bfs(0);
    cout << endl;

    return 0;
}

