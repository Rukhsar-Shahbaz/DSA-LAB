#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int d) {
        data = d;
        next = NULL;
    }
};

class Graph {
public:
    Node** adjList;
    int nodesCount;

    Graph(int n) {
        nodesCount = n;
        adjList = new Node*[n];
        for (int i = 0; i < n; i++) {
            adjList[i] = NULL;
        }
    }

    void addEdge(int src, int dest) {
        Node* newNode = new Node(dest);
        newNode->next = adjList[src];
        adjList[src] = newNode;

        newNode = new Node(src);
        newNode->next = adjList[dest];
        adjList[dest] = newNode;
    }

    void preorder(int node, bool visited[]) {
        visited[node] = true;
        cout << node << " ";
        Node* temp = adjList[node];
        while (temp != NULL) {
            if (!visited[temp->data]) {
                preorder(temp->data, visited);
            }
            temp = temp->next;
        }
    }

    void inorder(int node, bool visited[]) {
        visited[node] = true;
        Node* temp = adjList[node];

        
        while (temp != NULL) {
            if (!visited[temp->data]) {
                inorder(temp->data, visited);
                break;
            }
            temp = temp->next;
        }

        cout << node << " ";

        temp = adjList[node];
        while (temp != NULL) {
            if (!visited[temp->data]) {
                inorder(temp->data, visited);
            }
            temp = temp->next;
        }
    }

    void postorder(int node, bool visited[]) {
        visited[node] = true;
        Node* temp = adjList[node];
        while (temp != NULL) {
            if (!visited[temp->data]) {
                postorder(temp->data, visited);
            }
            temp = temp->next;
        }
        cout << node << " ";
    }
};

int main() {
    int nodes = 5;
    Graph g(nodes);

    g.addEdge(0, 1);
    g.addEdge(0, 4);
    g.addEdge(1, 2);
    g.addEdge(1, 3);
    g.addEdge(1, 4);
    g.addEdge(3, 4);

    bool visited[nodes] = {false};

    cout << "Preorder DFS: ";
    g.preorder(0, visited);
    cout << endl;

    fill(visited, visited + nodes, false);
    cout << "Inorder DFS: ";
    g.inorder(0, visited);
    cout << endl;

    fill(visited, visited + nodes, false);
    cout << "Postorder DFS: ";
    g.postorder(0, visited);
    cout << endl;

    return 0;
}

