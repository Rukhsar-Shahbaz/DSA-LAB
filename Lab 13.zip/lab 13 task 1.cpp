#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* child;

    Node(int d) {
        data = d;
        child = NULL;
    }
};

class Tree {
public:
    Node* insert(Node* root, int value) {
        if (root == NULL)
            return new Node(value);
        else
            root->child = insert(root->child, value);
        return root;
    }

    void preorder(Node* root) {
        if (root != NULL) {
            cout << root->data << " ";  
            preorder(root->child);     
        }
    }

    void inorder(Node* root) {
        if (root != NULL) {
            inorder(root->child);       
            cout << root->data << " "; 
        }
    }

    void postorder(Node* root) {
        if (root != NULL) {
            postorder(root->child);     
            cout << root->data << " ";  
        }
    }
};

int main() {
    Tree t;
    Node* root = NULL;

    root = t.insert(root, 10);
    t.insert(root, 20);
    t.insert(root, 30);
    t.insert(root, 40);

    cout << "Preorder Traversal: ";
    t.preorder(root);
    cout << endl;

    cout << "Inorder Traversal: ";
    t.inorder(root);
    cout << endl;

    cout << "Postorder Traversal: ";
    t.postorder(root);
    cout << endl;

    return 0;
}

